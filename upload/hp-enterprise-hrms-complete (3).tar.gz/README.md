# HP Enterprise HRMS — Complete Source Code

## Quick Start

```bash
# 1. Install dependencies
bun install

# 2. Create the database directory and push the schema
#    The .env file has: DATABASE_URL=file:./db/custom.db
mkdir -p db
bun run db:push

# 3. Seed the database (creates Owner, Admin, HR, Employee accounts)
bun run src/lib/seed.ts

# 4. Start the dev server
bun run dev
#    App runs at http://localhost:3000
```

> **Note:** If `bun run db:push` doesn't create the database file, make sure the `db/` folder exists (`mkdir -p db`) and that your `.env` file contains `DATABASE_URL=file:./db/custom.db`. On some setups you may need to use an absolute path like `DATABASE_URL=file:/absolute/path/to/project/db/custom.db`.

## Login Credentials (seeded)

| Role       | Username        | Password         | What they can do |
|------------|-----------------|------------------|------------------|
| **Owner**  | `owner`         | `Owner@123`      | Everything — creates Admin/HR accounts, full control |
| **Admin**  | `superadmin`    | `Admin@123`      | Operations + payroll + delete (no user management) |
| **HR**     | `hrmanager`     | `Hrmanager@123`  | Verify documents, manage employees (no payroll/settings) |
| **Employee**| `arjun.sharma` | `Employee@123`   | Self-service portal |

## Role Hierarchy

```
Owner (👑) → Admin (🛡️) → HR Manager (🛡️) → Employee
```

- **Owner**: Only role that creates Admin/HR accounts. Full control including Settings.
- **Admin**: Full operations + payroll. Cannot manage user accounts or settings.
- **HR Manager**: Verify documents, interview, approve/reject candidates. No payroll, no settings, no delete.
- **Employee**: Self-service portal only (attendance, leave, documents, profile).

## Features

### Public (no login)
- Employee Registration Form (7-step wizard with document uploads)

### Admin/HR Panel (Owner + Admin + HR)
- Dashboard with stats & charts
- Employee management (approve/reject/edit/delete + auto credential generation)
- Document verification (HR verifies each uploaded document)
- Interview workflow (schedule → pass/fail)
- Assign client to employee
- Attendance management (with location tracking)
- Leave management (approve/reject)
- Payroll (PF/ESI/LOP calculation + salary slip PDF) — Owner + Admin only
- Clients, Projects, Work Orders, Invoices (CRUD)
- Reports (7 types, CSV export)
- Document generation (16 HR letter types with HP branding)
- Announcements (broadcast to all)
- Audit logs
- User Accounts (Owner only — create Admin/HR)
- Settings (Owner only — payroll/leave config)

### Employee Portal
- Dashboard with stats
- My Profile (edit permitted fields)
- Attendance (punch in/out with geolocation)
- Apply Leave
- Documents (download offer/appointment/ID card/salary slips)
- Salary Slips
- Notifications (live SSE)
- Change Password (forced on first login)

### Real-Time (SSE)
All notifications push instantly via Server-Sent Events:
- New application → Admin sees toast instantly
- Leave applied → Admin sees toast instantly
- Leave approved → Employee sees toast instantly
- Salary slip generated → Employee sees toast instantly
- Announcement → All users see toast instantly

## Tech Stack
- Next.js 16 (App Router) + TypeScript
- Tailwind CSS 4 + shadcn/ui
- Prisma ORM (SQLite dev / PostgreSQL production)
- JWT cookie authentication (jose)
- @react-pdf/renderer for PDF generation
- Server-Sent Events for real-time updates

## Production Checklist
- [ ] Set `DATABASE_URL` to PostgreSQL (Supabase recommended)
- [ ] Set `JWT_SECRET` to a strong random value
- [ ] Configure SMTP for email notifications
- [ ] Move file uploads to S3/Supabase Storage
- [ ] Deploy to Vercel or your own server
- [ ] Update GSTIN/CIN in `src/lib/constants.ts` (BRAND object)

## File Structure
```
src/
├── app/
│   ├── api/              # 39 API route files
│   │   ├── auth/         # login, logout, me, reset-password
│   │   ├── admin/        # stats, employees, attendance, leaves, payroll, clients, projects, etc.
│   │   ├── employee/     # dashboard, attendance, profile, notifications, salary-slips
│   │   ├── registration  # public registration form
│   │   ├── sse           # Server-Sent Events stream
│   │   ├── documents/    # PDF download
│   │   └── uploads/      # uploaded file download
│   ├── page.tsx          # SPA entry point
│   ├── layout.tsx        # root layout
│   └── globals.css       # HP navy/gold brand theme
├── components/
│   ├── admin/            # AdminLayout + 15 modules
│   ├── employee/         # EmployeeLayout + 8 modules
│   ├── auth/             # Landing, RegistrationForm, ForgotPassword
│   ├── brand/            # BrandLogo
│   ├── shared/           # StatCard, StatusBadge, etc.
│   └── ui/               # shadcn/ui components
└── lib/
    ├── auth.ts           # JWT + password hashing + role guards
    ├── constants.ts      # Brand colors, roles, domain types
    ├── db.ts             # Prisma client
    ├── notify.ts         # notify() helper (DB + SSE push)
    ├── sse-bus.ts        # Global SSE pub/sub (survives HMR)
    ├── pdfgen.tsx        # HP-branded PDF document generation
    ├── docservice.ts     # Document generation service
    ├── audit.ts          # Audit logging
    ├── guards.ts         # requireRole() helper
    ├── seed.ts           # Database seeder
    ├── store.ts          # Zustand auth store
    ├── types.ts          # Shared types
    └── utils.ts          # cn() helper
```

## Important Rules
1. **Always use `notify()` from `@/lib/notify`** for notifications — never `db.notification.create` directly (that bypasses SSE).
2. **Role checks are enforced at the API layer** via `requireRole()` — not just hidden in the UI.
3. **The SSE bus** at `src/lib/sse-bus.ts` uses `globalThis` to survive HMR — don't move it back into a route file.
4. Run `bun run lint` before considering any change done.
